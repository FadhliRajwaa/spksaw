<?php
header ('location:administrator');
?>